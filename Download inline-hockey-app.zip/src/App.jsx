import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import PlayerList from './components/PlayerList';
import SessionList from './components/SessionList';
import AttendancePage from './components/AttendancePage';

const supabase = createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_KEY);

export default function App() {
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });
    supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });
  }, []);

  return (
    <Router>
      <Routes>
        {!session ? (
          <Route path="*" element={<Login supabase={supabase} />} />
        ) : (
          <>
            <Route path="/" element={<Dashboard />} />
            <Route path="/players" element={<PlayerList supabase={supabase} />} />
            <Route path="/sessions" element={<SessionList supabase={supabase} />} />
            <Route path="/attendance" element={<AttendancePage supabase={supabase} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </>
        )}
      </Routes>
    </Router>
  );
}
